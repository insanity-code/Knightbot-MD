const settings = {
  packname: 'Knight Bot',
  author: '‎',
  botName: "Knight Bot",
  botOwner: 'Insanity bot', // Your name
  ownerNumber: '2349136791372', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.0",
};

module.exports = settings;
